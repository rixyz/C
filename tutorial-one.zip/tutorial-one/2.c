//WAP that input seconds as input and converts to minutes.
#include <stdio.h>
int main() {
    int s,m;
    printf("Enter seconds: ");
    scanf("%d",&s);
    printf("Minutes: %d",s/60);
    return 0;
}
